var res={"status":1,"id":"electionresults","data":{"M":"17.8","C":"9.7","FP":"3.5","KD":"2.6","MP":"4.7","S":"29.3","V":"3.1","SD":"26.4","\u00d6VRIGA":"3.1","OGILTIGA":"..","VALSKOLKARE":".."}};

